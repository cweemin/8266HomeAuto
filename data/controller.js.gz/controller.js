angular.module('SwitchApp', ['ngMaterial'])
.controller('SwitchCtrl',['$scope', '$http', function($scope,$http) {
	//var url='http://192.168.0.15';
	var url='';
	$scope.temp = 0.0;
	$scope.errorTemp = false;
	$scope.gotTemp = false;
	$scope.temp_unit = 'F';
	$scope.array1 = ['LivingRoom Light', 'LivingRoom Fan'];
	$scope.changeUnit = function() {
	var tmp=0.0;
	if ($scope.temp_unit === 'C') {
	tmp = $scope.rawTemp / 10.0;
	} else {
	tmp = $scope.rawTemp * 9.0 / 50.0 + 32.0;
	}
	$scope.temp = tmp.toFixed(1);
	};
	$scope.LivingRoomButton = function(btn, onoff) {
	var type_to_send;
	if (btn === $scope.array1[0]) {
	type_to_send = 1
	} else {
	    type_to_send = 2;
	}
	$http.get(url+'/switch',{params:{type:type_to_send, status:onoff}});
	};
	$scope.KitchenButton = function() {
	    $http.get(url+'/switch', {params:{type: 0, status:0}});
	};
	$scope.getTemp = function(which) {
	    $http.get(url+'/'+ which).then(function(res) {
		    if(res.status === 200) {
		    $scope.errorTemp = false
		    $scope.gotTemp = true;
		    $scope.rawTemp = parseInt(res.data['RawTemp']);
		    $scope.changeUnit();
		    if(which === 'weather') {
			$scope.humidity = parseInt(res.data['Humidity']);
		    } else {
		        $scope.humidity = null;
		    }
		    $scope.temp_date = new Date(parseInt(res.data['Time']) *1000);
		    $scope.temp_ts = $scope.temp_date.toUTCString();
		    }
		    }, function(errorRes) {
		    if (errorRes.status === 500 && errorRes.data.indexOf('DATA NOT AVAILABLE') != -1) {
		    $scope.errorTemp = 'Temperature not ready come back later!';
		    $scope.gotTemp = false;
		    }
		    });
	};
}]);
